#!/bin/sh

# Install the EmulationStation build from the screenscraper-advanced directory
# beside this script on a ROCKNIX device.
# The stock /usr/bin/emulationstation is on a read-only filesystem, so the
# custom binary is kept in /storage and bind-mounted over the stock binary.

set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
BUILD_DIR=$SCRIPT_DIR/screenscraper-advanced
SOURCE_BINARY=${EMULATIONSTATION_BINARY:-"$BUILD_DIR/emulationstation"}
CHECKSUM_FILE=${EMULATIONSTATION_CHECKSUM:-"$BUILD_DIR/emulationstation.sha256"}
INSTALL_DIR=/storage/.config/emulationstation
SYSTEMD_DIR=/storage/.config/system.d
INSTALLED_BINARY=$INSTALL_DIR/emulationstation.new
STAGED_BINARY=$INSTALL_DIR/emulationstation.next
PREVIOUS_BINARY=$INSTALL_DIR/emulationstation.previous
SERVICE_FILE=$SYSTEMD_DIR/emulationstation-custom.service
TARGET_BINARY=/usr/bin/emulationstation

fail() {
    printf 'Error: %s\n' "$*" >&2
    exit 1
}

[ "$(id -u)" -eq 0 ] || fail "run this script as root"
[ -f "$SOURCE_BINARY" ] || fail "binary not found: $SOURCE_BINARY"
[ -x "$TARGET_BINARY" ] || fail "stock EmulationStation not found: $TARGET_BINARY"
command -v systemctl >/dev/null 2>&1 || fail "systemctl is required"
command -v sha256sum >/dev/null 2>&1 || fail "sha256sum is required"

case "$(uname -m)" in
    aarch64|arm64) ;;
    *) fail "this build requires an aarch64 device (found $(uname -m))" ;;
esac

actual_hash=$(sha256sum "$SOURCE_BINARY" | awk '{print $1}')
if [ -f "$CHECKSUM_FILE" ]; then
    expected_hash=$(awk 'NF {print $1; exit}' "$CHECKSUM_FILE")
    [ -n "$expected_hash" ] || fail "checksum file is empty: $CHECKSUM_FILE"
    [ "$actual_hash" = "$expected_hash" ] || \
        fail "checksum mismatch (expected $expected_hash, got $actual_hash)"
else
    printf 'Warning: no checksum file found at %s\n' "$CHECKSUM_FILE" >&2
fi

mkdir -p "$INSTALL_DIR" "$SYSTEMD_DIR"
cp "$SOURCE_BINARY" "$STAGED_BINARY"
chmod 755 "$STAGED_BINARY"
staged_hash=$(sha256sum "$STAGED_BINARY" | awk '{print $1}')
[ "$staged_hash" = "$actual_hash" ] || fail "staged binary failed checksum verification"
sync

ui_service=
for candidate in essway.service emustation.service; do
    if systemctl cat "$candidate" >/dev/null 2>&1; then
        ui_service=$candidate
        break
    fi
done
[ -n "$ui_service" ] || fail "could not find essway.service or emustation.service"

cat >"$SERVICE_FILE" <<'EOF'
[Unit]
Description=Install persistent custom EmulationStation binary
RequiresMountsFor=/storage/.config/emulationstation/emulationstation.new
Before=essway.service emustation.service

[Service]
Type=oneshot
ExecStart=/bin/mount --bind /storage/.config/emulationstation/emulationstation.new /usr/bin/emulationstation
ExecStop=/bin/umount /usr/bin/emulationstation
RemainAfterExit=yes

[Install]
WantedBy=rocknix.target
EOF

systemctl stop "$ui_service"
if systemctl is-active --quiet emulationstation-custom.service 2>/dev/null; then
    systemctl stop emulationstation-custom.service
elif awk -v target="$TARGET_BINARY" '$2 == target { found=1 } END { exit !found }' /proc/mounts; then
    umount "$TARGET_BINARY"
fi

if [ -f "$INSTALLED_BINARY" ]; then
    cp "$INSTALLED_BINARY" "$PREVIOUS_BINARY"
    chmod 755 "$PREVIOUS_BINARY"
fi
mv "$STAGED_BINARY" "$INSTALLED_BINARY"
chmod 755 "$INSTALLED_BINARY"

systemctl daemon-reload
systemctl enable emulationstation-custom.service >/dev/null

if ! systemctl start emulationstation-custom.service; then
    printf 'Failed to mount the new build; restoring the UI with the stock binary.\n' >&2
    systemctl disable emulationstation-custom.service >/dev/null 2>&1 || true
    systemctl start "$ui_service" || true
    exit 1
fi

if ! systemctl start "$ui_service"; then
    printf 'The custom build was mounted, but %s failed to start.\n' "$ui_service" >&2
    printf 'Run: journalctl -u %s -u emulationstation-custom.service\n' "$ui_service" >&2
    exit 1
fi

live_hash=$(sha256sum "$TARGET_BINARY" | awk '{print $1}')
[ "$live_hash" = "$actual_hash" ] || fail "live binary checksum does not match the build"

printf '\nEmulationStation patch installed successfully.\n'
printf 'Build SHA-256: %s\n' "$live_hash"
printf 'UI service:       %s\n' "$ui_service"
printf 'Persistent unit:  %s\n' "$SERVICE_FILE"
printf 'Previous build:   %s\n' "$PREVIOUS_BINARY"
